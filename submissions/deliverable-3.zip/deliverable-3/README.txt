# Seg 2105 Term Project
Repo: https://github.com/KyleDulce-UO/seg2105
Release Page: https://github.com/KyleDulce-UO/seg2105/releases

## Testing Details
Confirmed to work properly (and see all elements properly) using:
Device: Pixel 3a
API: 30

## Students
Kyle Jacob Dulce 300169731

Kevin Le 300053306

Xingjian (Jason) Su 300074626

Alexandra Tulchinsky 300165864

Ritvik Johar 300074686

**Note:** Kyle Dulce has 2 github accounts, (KyleDulce-UO - The account with the GitHub Student Developer Pack and hosts the private repo, KyleDulce - My Main/Personal Github account). They both belong to Kyle Dulce but KyleDulce will be making the bulk of commits.

Thank you!!!!

**Note:** SEG2105-F2021 was invited to the repo
**Note:** Check releases for the final commit before submission onto brightspace. Their state are kept to help you.