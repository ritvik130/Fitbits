package me.seg.fitbites.firebase;

import java.util.ArrayList;

import me.seg.fitbites.data.ClassInfoDisplay;

public interface OnObjectFilled {
    public void onObjectReady();
}
