package me.seg.fitbites.firebase;

import java.util.ArrayList;

import me.seg.fitbites.data.ClassInfoDisplay;

public interface nObjectFilled {
    public void onObjectReady();
}
