package me.seg.fitbites.data;

public class Admin extends UserData {

    public Admin() {

        // username and password as specified in the instructions
        super("AdminId", "Admin FirstName", "Admin Lastname","Admin","", "0", "admin123", "admin");
    }

}
