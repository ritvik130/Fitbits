package me.seg.fitbites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddNewClass extends AppCompatActivity {
    private String className, classDescription;
    private TextView classNameInput, classDescriptionInput;
    private Button submitButton, bkBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_new_class);
        classNameInput=(TextView) findViewById(R.id.textView7);
        classDescriptionInput=(TextView) findViewById(R.id.textView8);
        submitButton = (Button) findViewById(R.id.button1);
        bkBtn = (Button) findViewById(R.id.add_btn_bk);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                className = classNameInput.getText().toString();
                classDescription = classDescriptionInput.getText().toString();
                newFitClass(className, classDescription);
                Intent i = new Intent(AddNewClass.this, ManageClassScreen.class);
                startActivity(i);
            }
        });

        bkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AddNewClass.this, AdminLogin.class);
                startActivity(i);
            }
        });
    }
    private void newFitClass(String className, String classDescription ){
        FitClassType.createFitClassType(className, classDescription);
    }

}
